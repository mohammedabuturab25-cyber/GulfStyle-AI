# GulfStyle AI Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based (Luxury E-commerce)

Drawing inspiration from Net-a-Porter, Farfetch, and luxury Middle Eastern brands like The Modist and Ounass. This platform demands premium aesthetics that honor Gulf cultural values while embracing modern AI innovation.

**Core Principles:**
- Luxurious restraint: Generous whitespace conveys premium positioning
- Cultural reverence: Elegant without ostentation, modest without austerity
- Bilingual excellence: Seamless English/Arabic experience with flawless RTL support
- AI transparency: Technology enhances rather than dominates the experience

---

## Typography System

**Primary Typeface (Headings):** Playfair Display
- Hero headlines: 4xl to 6xl (48-60px desktop, 32-40px mobile)
- Section titles: 3xl to 4xl (36-48px desktop, 28-32px mobile)
- Card headings: xl to 2xl (20-24px)
- Weights: 400 (regular), 600 (semibold), 700 (bold)

**Secondary Typeface (Body):** Poppins
- Body text: base to lg (16-18px)
- Captions/metadata: sm (14px)
- Weights: 300 (light), 400 (regular), 500 (medium), 600 (semibold)

**Hierarchy Rules:**
- All headings use Playfair Display with generous letter-spacing (tracking-wide)
- Body content uses Poppins for optimal readability
- Arabic text receives equal typographic treatment with appropriate font substitutes (Tajawal or Cairo for Arabic)

---

## Layout System

**Spacing Primitives:** Tailwind units of 4, 6, 8, 12, 16, 20, 24
- Component padding: p-6 to p-8
- Section spacing: py-16 to py-24 (desktop), py-12 to py-16 (mobile)
- Card gaps: gap-6 to gap-8
- Element margins: mt-4, mb-6, mx-8

**Container Strategy:**
- Maximum content width: max-w-7xl (1280px)
- Narrow content (text): max-w-4xl (896px)
- Product grids: max-w-6xl (1152px)
- Full-bleed sections for visual impact

**Grid Systems:**
- Product cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Feature showcases: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Testimonials: grid-cols-1 md:grid-cols-2
- Mobile: Always single column with generous padding

---

## Component Library

### Navigation
**Desktop Header:**
- Fixed/sticky navigation with subtle backdrop blur
- Logo (left) + primary navigation (center) + CTA + language toggle + cart (right)
- Primary nav items: Home, AI Stylist, Shop, Collections, Influencers, About
- Height: 20 (80px) with py-6 internal padding

**Mobile Navigation:**
- Hamburger menu revealing full-screen overlay
- Large touch targets (min 44px)
- Language toggle prominent in mobile menu

### Hero Section (Homepage)
**Layout:**
- Full-width hero spanning 85vh with elegant product imagery
- Asymmetric split: 40% content (left) / 60% imagery (right) on desktop
- Content includes: Main headline, subheadline (2-3 lines), dual CTAs
- Overlay gradient for text legibility on image backgrounds
- Buttons with backdrop-blur-md backgrounds when over images

**Content:**
- Headline: "Discover Your Perfect Style with AI-Powered Elegance"
- Subheadline: Introduce Layla, the AI stylist, and Gulf luxury promise
- Primary CTA: "Start Styling" / Secondary CTA: "Explore Collections"

### AI Stylist Interface
**Interactive Upload Section:**
- Large dropzone area (min 400px height) with elegant border treatment
- Upload states: idle, dragging, processing, complete
- Image preview with elegant frame treatment
- Chat-style interface below with Layla's recommendations
- Results displayed as outfit cards with product details

### Product Cards
**Standard Card Structure:**
- Image ratio: 4:5 (portrait) for fashion items
- Hover state: Subtle scale (1.02) with smooth transition
- Content: Designer name (small caps), product name, price, quick-view icon
- Add to wishlist icon (top-right corner)
- Consistent 4px rounded corners

### Collections Showcase
**Gulf-Centric Display:**
- Hero image for each collection (Abayas, Thobes, Kaftans, Perfumes)
- Grid layout with overlapping cards for visual interest
- Designer spotlight sections with portrait + bio + featured pieces
- Regional tags: Dubai, Muscat, Riyadh with elegant iconography

### Influencer Feed
**Social Grid Layout:**
- Masonry-style grid (Pinterest-inspired) for varied content heights
- Each card: Influencer image, caption preview, engagement metrics
- Filter tags: Occasion, Style, Designer
- Infinite scroll with elegant loading states

### Smart Closet Interface
**Wardrobe Management:**
- Grid of user-uploaded items with category tags
- "Create Outfit" button triggers AI matching
- Results shown as outfit combinations with styling tips from Layla
- Save/share functionality for favorite combinations

### Forms & Inputs
**Style:**
- Elegant borders with subtle shadows (shadow-sm)
- Focus states with refined ring treatment (ring-2)
- Generous padding (px-4 py-3)
- Labels in Poppins medium weight
- Error states with graceful messaging

### Buttons
**Primary Actions:**
- Large touch targets (px-8 py-4)
- Rounded corners (rounded-lg)
- Weight: font-medium (500)
- Disabled states with reduced opacity

**Secondary Actions:**
- Outlined style with border-2
- Same sizing as primary for consistency

### Footer
**Comprehensive Layout:**
- Four-column grid: About, Quick Links, Collections, Newsletter
- Social media links with icon treatment
- Newsletter signup with inline form
- Language switcher + currency selector
- Trust badges: Secure payment, Gulf authenticity certification
- Copyright with elegant divider

---

## Bilingual Implementation (Critical)

**RTL Support:**
- Mirror all layouts for Arabic (dir="rtl")
- Flip navigation, grids, and asymmetric layouts
- Icons and illustrations remain directionally neutral
- Forms maintain logical flow in RTL
- Test all interactions in both directions

**Language Toggle:**
- Prominent placement in header (globe icon + EN/AR)
- Instant language switch without page reload
- Persist language preference

**Typography Adjustments:**
- Arabic: Use Tajawal (400, 500, 700) or Cairo font family
- Increase line-height by 1.2x for Arabic readability
- Maintain visual hierarchy across both languages

---

## Images

**Hero Section (Homepage):**
Large, elegant lifestyle image showcasing a woman in luxury modest wear (abaya/kaftan) in a sophisticated Gulf setting (modern architecture, desert landscape, or luxury interior). Image should convey elegance, confidence, and cultural pride. Aspect ratio 16:9, high resolution.

**AI Stylist Page:**
Interactive demonstration image showing the AI styling process - split-screen showing user photo input and AI-generated outfit recommendations.

**Collection Headers:**
Four distinct hero images for each collection category:
- Abayas: Flowing, elegant silhouettes with intricate details
- Thobes: Contemporary men's fashion with traditional elements
- Kaftans: Luxurious evening wear with Gulf aesthetics
- Perfumes: Artistic product photography with Middle Eastern ambiance

**Product Images:**
Portrait orientation (4:5 ratio), clean backgrounds, multiple angles per product, lifestyle shots showing items styled on models.

**Influencer Feed:**
Mix of lifestyle photography, outfit flatlays, and styled looks in Gulf settings. Authentic, aspirational imagery that resonates with target audience.

**About Page:**
Brand story imagery: local designers at work, fabric close-ups, Gulf landmarks, cultural elements presented elegantly.

---

## Animations (Minimal & Purposeful)

- Page transitions: Smooth fade-in (300ms)
- Card hover: Subtle lift (scale 1.02, shadow increase)
- Image loading: Elegant skeleton states
- AI processing: Refined spinner or progress indicator
- NO distracting scroll animations
- NO auto-playing videos or carousels (user-controlled only)

---

## Accessibility

- WCAG AA contrast ratios minimum
- Keyboard navigation for all interactive elements
- Screen reader optimized for both English and Arabic
- Focus indicators visible and elegant
- Alt text for all imagery, especially product photos
- Touch targets minimum 44x44px

---

## Page-Specific Layouts

**Homepage:**
1. Hero (85vh) with asymmetric content/image split
2. AI Stylist Preview (interactive demo section)
3. Featured Collections (4-column grid)
4. How It Works (3-step process with icons)
5. Influencer Spotlight (carousel or grid preview)
6. Trust Indicators (local designers, AI technology, cultural authenticity)
7. Newsletter Signup (elegant centered section)

**Shop Page:**
- Filter sidebar (collapsible on mobile)
- Product grid with infinite scroll
- Quick view modal for product preview
- Breadcrumb navigation

**AI Stylist Page:**
- Full-width interactive interface
- Upload section prominent
- Chat-style results display
- Save/share functionality

---

## Responsive Breakpoints

- Mobile: < 768px (single column, stacked layouts)
- Tablet: 768px - 1024px (2-column grids)
- Desktop: > 1024px (full layouts, 3-4 column grids)
- Large: > 1280px (maximum content width with generous margins)