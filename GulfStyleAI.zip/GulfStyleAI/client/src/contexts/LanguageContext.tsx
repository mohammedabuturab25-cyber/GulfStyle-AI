import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Navigation
    home: 'Home',
    aiStylist: 'AI Stylist',
    shop: 'Shop',
    collections: 'Collections',
    influencers: 'Influencers',
    closet: 'My Closet',
    about: 'About',
    contact: 'Contact',
    cart: 'Cart',
    
    // Hero
    heroTitle: 'Discover Your Perfect Style',
    heroSubtitle: 'AI-Powered Elegance for Gulf Luxury Fashion',
    heroDescription: 'Meet Layla, your personal AI fashion assistant. Experience personalized modest fashion recommendations crafted for the modern Gulf woman.',
    startStyling: 'Start Styling',
    exploreCollections: 'Explore Collections',
    
    // AI Stylist
    meetLayla: 'Meet Layla',
    aiAssistant: 'Your AI Fashion Assistant',
    uploadPhoto: 'Upload Your Photo',
    describeStyle: 'Or Describe Your Style',
    getRecommendations: 'Get Recommendations',
    analyzing: 'Analyzing your style...',
    laylaResponse: 'Layla\'s Recommendations',
    
    // Products
    allProducts: 'All Products',
    filterBy: 'Filter By',
    category: 'Category',
    modestyLevel: 'Modesty Level',
    occasion: 'Occasion',
    designer: 'Designer',
    priceRange: 'Price Range',
    addToCart: 'Add to Cart',
    viewDetails: 'View Details',
    inStock: 'In Stock',
    outOfStock: 'Out of Stock',
    
    // Collections
    gulfCollections: 'Gulf Collections',
    luxuryAbayas: 'Luxury Abayas',
    elegantThobes: 'Elegant Thobes',
    eveningKaftans: 'Evening Kaftans',
    viewCollection: 'View Collection',
    
    // Footer
    aboutUs: 'About Us',
    ourMission: 'Our Mission',
    newsletter: 'Newsletter',
    subscribeNewsletter: 'Subscribe to Newsletter',
    emailPlaceholder: 'Enter your email',
    subscribe: 'Subscribe',
    followUs: 'Follow Us',
    allRightsReserved: 'All rights reserved',
    
    // Cart & Checkout
    shoppingCart: 'Shopping Cart',
    emptyCart: 'Your cart is empty',
    subtotal: 'Subtotal',
    total: 'Total',
    checkout: 'Checkout',
    continueShopping: 'Continue Shopping',
    
    // Common
    loading: 'Loading...',
    error: 'Error',
    tryAgain: 'Try Again',
    close: 'Close',
    save: 'Save',
    cancel: 'Cancel',
  },
  ar: {
    // Navigation
    home: 'الرئيسية',
    aiStylist: 'المصممة الذكية',
    shop: 'تسوق',
    collections: 'المجموعات',
    influencers: 'المؤثرون',
    closet: 'خزانتي',
    about: 'من نحن',
    contact: 'اتصل بنا',
    cart: 'السلة',
    
    // Hero
    heroTitle: 'اكتشفي أسلوبك المثالي',
    heroSubtitle: 'الأناقة المدعومة بالذكاء الاصطناعي لأزياء الخليج الفاخرة',
    heroDescription: 'تعرفي على ليلى، مساعدتك الشخصية في عالم الموضة. استمتعي بتوصيات الأزياء المحتشمة المصممة خصيصاً للمرأة الخليجية العصرية.',
    startStyling: 'ابدأي التنسيق',
    exploreCollections: 'استكشفي المجموعات',
    
    // AI Stylist
    meetLayla: 'تعرفي على ليلى',
    aiAssistant: 'مساعدتك الذكية في الموضة',
    uploadPhoto: 'ارفعي صورتك',
    describeStyle: 'أو صفي أسلوبك',
    getRecommendations: 'احصلي على التوصيات',
    analyzing: 'جاري تحليل أسلوبك...',
    laylaResponse: 'توصيات ليلى',
    
    // Products
    allProducts: 'جميع المنتجات',
    filterBy: 'تصفية حسب',
    category: 'الفئة',
    modestyLevel: 'مستوى الاحتشام',
    occasion: 'المناسبة',
    designer: 'المصمم',
    priceRange: 'نطاق السعر',
    addToCart: 'أضف للسلة',
    viewDetails: 'عرض التفاصيل',
    inStock: 'متوفر',
    outOfStock: 'غير متوفر',
    
    // Collections
    gulfCollections: 'مجموعات الخليج',
    luxuryAbayas: 'عباءات فاخرة',
    elegantThobes: 'ثياب أنيقة',
    eveningKaftans: 'قفاطين سهرة',
    viewCollection: 'عرض المجموعة',
    
    // Footer
    aboutUs: 'من نحن',
    ourMission: 'مهمتنا',
    newsletter: 'النشرة الإخبارية',
    subscribeNewsletter: 'اشترك في النشرة',
    emailPlaceholder: 'أدخل بريدك الإلكتروني',
    subscribe: 'اشترك',
    followUs: 'تابعنا',
    allRightsReserved: 'جميع الحقوق محفوظة',
    
    // Cart & Checkout
    shoppingCart: 'سلة التسوق',
    emptyCart: 'سلتك فارغة',
    subtotal: 'المجموع الفرعي',
    total: 'الإجمالي',
    checkout: 'الدفع',
    continueShopping: 'متابعة التسوق',
    
    // Common
    loading: 'جاري التحميل...',
    error: 'خطأ',
    tryAgain: 'حاول مرة أخرى',
    close: 'إغلاق',
    save: 'حفظ',
    cancel: 'إلغاء',
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLang = localStorage.getItem('gulfstyle-language') as Language;
    if (savedLang && (savedLang === 'en' || savedLang === 'ar')) {
      setLanguage(savedLang);
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('gulfstyle-language', language);
  }, [language]);

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ar' : 'en');
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
