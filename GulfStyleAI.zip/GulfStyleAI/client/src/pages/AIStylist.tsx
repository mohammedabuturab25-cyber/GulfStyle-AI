import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import { Upload, Sparkles, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import aiStylistDemo from "@assets/generated_images/AI_stylist_interface_demo_db6457ca.png";

export default function AIStylist() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [userInput, setUserInput] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recommendations, setRecommendations] = useState<string>("");

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGetRecommendations = async () => {
    if (!userInput && !imageFile) {
      toast({
        title: t('language') === 'ar' ? 'خطأ' : 'Error',
        description: t('language') === 'ar' 
          ? 'الرجاء إدخال وصف أو تحميل صورة'
          : 'Please provide a description or upload an image',
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    try {
      const formData = new FormData();
      formData.append('userInput', userInput);
      if (imageFile) {
        formData.append('image', imageFile);
      }

      const response = await fetch('/api/styling-request', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Failed to get recommendations');

      const data = await response.json();
      setRecommendations(data.aiResponse);
    } catch (error) {
      toast({
        title: t('error'),
        description: t('language') === 'ar'
          ? 'حدث خطأ أثناء الحصول على التوصيات'
          : 'Failed to get recommendations. Please try again.',
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-6">
            <Sparkles className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium text-primary">{t('aiAssistant')}</span>
          </div>
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6">
            {t('meetLayla')}
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {t('language') === 'ar'
              ? 'مرحباً! أنا ليلى، مساعدتك الشخصية في عالم الموضة. سأساعدك في اكتشاف أسلوبك المثالي واختيار الأزياء المحتشمة التي تناسب ذوقك وشخصيتك.'
              : 'Welcome! I\'m Layla, your personal AI fashion assistant. I\'ll help you discover your perfect style and choose modest fashion that suits your taste and personality.'}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-7xl mx-auto">
          {/* Input Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="font-serif text-2xl">
                  {t('language') === 'ar' ? 'شاركي أسلوبك' : 'Share Your Style'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Image Upload */}
                <div className="space-y-4">
                  <label className="block font-medium">{t('uploadPhoto')}</label>
                  <div className="border-2 border-dashed border-border rounded-md p-8 text-center hover-elevate transition-all" data-testid="container-image-upload">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                      id="image-upload"
                      data-testid="input-file-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer" data-testid="label-image-upload">
                      {imagePreview ? (
                        <div className="space-y-4">
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="max-h-64 mx-auto rounded-md object-cover"
                          />
                          <Button type="button" variant="outline" size="sm" data-testid="button-change-image">
                            {t('language') === 'ar' ? 'تغيير الصورة' : 'Change Image'}
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div className="h-16 w-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                            <Upload className="h-8 w-8 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium mb-1">
                              {t('language') === 'ar' ? 'اضغط لتحميل صورة' : 'Click to upload an image'}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {t('language') === 'ar' ? 'أو اسحب وأفلت' : 'or drag and drop'}
                            </p>
                          </div>
                        </div>
                      )}
                    </label>
                  </div>
                </div>

                {/* Text Description */}
                <div className="space-y-4">
                  <label className="block font-medium">{t('describeStyle')}</label>
                  <Textarea
                    placeholder={t('language') === 'ar'
                      ? 'صفي أسلوبك المفضل، المناسبة، الألوان، أو أي تفضيلات أخرى...'
                      : 'Describe your preferred style, occasion, colors, or any other preferences...'}
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    rows={6}
                    data-testid="input-style-description"
                    className="resize-none"
                  />
                </div>

                <Button
                  onClick={handleGetRecommendations}
                  disabled={isAnalyzing || (!userInput && !imageFile)}
                  className="w-full gap-2"
                  size="lg"
                  data-testid="button-get-recommendations"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      {t('analyzing')}
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-5 w-5" />
                      {t('getRecommendations')}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Response Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="font-serif text-2xl flex items-center gap-2">
                  <Sparkles className="h-6 w-6 text-primary" />
                  {t('laylaResponse')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recommendations ? (
                  <div className="prose prose-sm max-w-none">
                    <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                      {recommendations}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6 text-center py-12">
                    <img
                      src={aiStylistDemo}
                      alt="AI Stylist Demo"
                      className="w-full rounded-md opacity-50"
                    />
                    <div className="space-y-2">
                      <p className="text-muted-foreground">
                        {t('language') === 'ar'
                          ? 'ارفعي صورة أو صفي أسلوبك للحصول على توصيات مخصصة من ليلى'
                          : 'Upload an image or describe your style to get personalized recommendations from Layla'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {t('language') === 'ar'
                          ? 'ستظهر التوصيات هنا'
                          : 'Your recommendations will appear here'}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* How It Works */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-24"
        >
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
              {t('language') === 'ar' ? 'كيف يعمل؟' : 'How It Works'}
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                step: '1',
                title: t('language') === 'ar' ? 'شاركي تفضيلاتك' : 'Share Your Preferences',
                description: t('language') === 'ar'
                  ? 'ارفعي صورة أو صفي أسلوبك المفضل والمناسبة'
                  : 'Upload a photo or describe your preferred style and occasion',
              },
              {
                step: '2',
                title: t('language') === 'ar' ? 'تحليل ذكي' : 'AI Analysis',
                description: t('language') === 'ar'
                  ? 'تقوم ليلى بتحليل تفضيلاتك باستخدام الذكاء الاصطناعي المتقدم'
                  : 'Layla analyzes your preferences using advanced AI technology',
              },
              {
                step: '3',
                title: t('language') === 'ar' ? 'توصيات مخصصة' : 'Personalized Recommendations',
                description: t('language') === 'ar'
                  ? 'احصلي على اقتراحات أزياء مخصصة تناسب ذوقك'
                  : 'Receive tailored fashion suggestions that match your taste',
              },
            ].map((item, index) => (
              <Card key={index} className="text-center p-6" data-testid={`card-how-it-works-step-${index + 1}`}>
                <div className="h-16 w-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-serif text-2xl font-bold text-primary">{item.step}</span>
                </div>
                <h3 className="font-serif text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
              </Card>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
