import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { Loader2 } from "lucide-react";

// Make Stripe optional if credentials not provided
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : null;

const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const { language } = useLanguage();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin + '/order-success',
      },
    });

    if (error) {
      toast({
        title: language === 'ar' ? 'فشل الدفع' : 'Payment Failed',
        description: error.message,
        variant: "destructive",
      });
      setIsProcessing(false);
    } else {
      toast({
        title: language === 'ar' ? 'نجح الدفع' : 'Payment Successful',
        description: language === 'ar' ? 'شكراً لشرائك!' : 'Thank you for your purchase!',
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full"
        size="lg"
        data-testid="button-complete-payment"
      >
        {isProcessing ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin me-2" />
            {language === 'ar' ? 'جاري المعالجة...' : 'Processing...'}
          </>
        ) : (
          language === 'ar' ? 'إتمام الدفع' : 'Complete Payment'
        )}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [error, setError] = useState("");
  const { language } = useLanguage();

  useEffect(() => {
    if (!stripePromise) {
      setError("Payment processing is not available at this time.");
      return;
    }

    apiRequest("POST", "/api/create-payment-intent", { amount: 500 })
      .then((res) => res.json())
      .then((data) => {
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else {
          setError(data.message || "Failed to initialize payment");
        }
      })
      .catch((err) => {
        setError("Failed to connect to payment service");
      });
  }, []);

  if (error) {
    return (
      <div className="min-h-screen py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-2xl">
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">{error}</p>
          </Card>
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-2xl">
        <h1 className="font-serif text-5xl font-bold mb-12 text-center">
          {language === 'ar' ? 'الدفع' : 'Checkout'}
        </h1>
        <Card>
          <CardHeader>
            <CardTitle className="font-serif text-2xl">
              {language === 'ar' ? 'تفاصيل الدفع' : 'Payment Details'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stripePromise && (
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <CheckoutForm />
              </Elements>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
