import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import abayasImage from "@assets/generated_images/Abayas_collection_showcase_ec1506f0.png";
import thobesImage from "@assets/generated_images/Thobes_collection_display_16d9a5a5.png";
import kaftansImage from "@assets/generated_images/Kaftans_evening_wear_collection_3b94247d.png";

export default function Collections() {
  const { t, language } = useLanguage();

  const collections = [
    {
      id: 'abayas',
      name: t('luxuryAbayas'),
      nameAr: 'عباءات فاخرة',
      description: language === 'ar'
        ? 'مجموعة راقية من العباءات المصممة بعناية فائقة، تجمع بين الأصالة والعصرية'
        : 'An exquisite collection of carefully designed abayas, combining authenticity and modernity',
      image: abayasImage,
      region: 'Dubai',
      designer: language === 'ar' ? 'نور الشرق' : 'Noor Al Sharq',
      items: 45,
    },
    {
      id: 'thobes',
      name: t('elegantThobes'),
      nameAr: 'ثياب أنيقة',
      description: language === 'ar'
        ? 'ثياب رجالية فاخرة بتصاميم عصرية تحافظ على التقاليد الخليجية'
        : 'Luxury men\'s thobes with contemporary designs that preserve Gulf traditions',
      image: thobesImage,
      region: 'Riyadh',
      designer: language === 'ar' ? 'ملابس الرياض' : 'Riyadh Couture',
      items: 32,
    },
    {
      id: 'kaftans',
      name: t('eveningKaftans'),
      nameAr: 'قفاطين سهرة',
      description: language === 'ar'
        ? 'قفاطين ساحرة للمناسبات الخاصة، مطرزة بخيوط ذهبية وتفاصيل فاخرة'
        : 'Enchanting kaftans for special occasions, embroidered with gold threads and luxurious details',
      image: kaftansImage,
      region: 'Muscat',
      designer: language === 'ar' ? 'أناقة عمان' : 'Oman Elegance',
      items: 28,
    },
  ];

  const designers = [
    {
      name: language === 'ar' ? 'فاطمة الزهراني' : 'Fatima Al-Zahrani',
      region: 'Dubai',
      specialty: language === 'ar' ? 'عباءات فاخرة' : 'Luxury Abayas',
      description: language === 'ar'
        ? 'مصممة إماراتية رائدة في مجال الأزياء المحتشمة الفاخرة'
        : 'Leading Emirati designer in luxury modest fashion',
    },
    {
      name: language === 'ar' ? 'عبدالله القحطاني' : 'Abdullah Al-Qahtani',
      region: 'Riyadh',
      specialty: language === 'ar' ? 'ثياب رجالية' : 'Men\'s Thobes',
      description: language === 'ar'
        ? 'متخصص في الثياب الرجالية الفاخرة بلمسات عصرية'
        : 'Specializes in luxury men\'s thobes with contemporary touches',
    },
    {
      name: language === 'ar' ? 'نورة البلوشي' : 'Noura Al-Balushi',
      region: 'Muscat',
      specialty: language === 'ar' ? 'قفاطين سهرة' : 'Evening Kaftans',
      description: language === 'ar'
        ? 'خبيرة في تصميم القفاطين العمانية التقليدية بأسلوب معاصر'
        : 'Expert in traditional Omani kaftans with a modern twist',
    },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6">
            {t('gulfCollections')}
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {language === 'ar'
              ? 'استكشفي مجموعاتنا الحصرية المستوحاة من جمال وأناقة الخليج العربي'
              : 'Explore our exclusive collections inspired by the beauty and elegance of the Arabian Gulf'}
          </p>
        </motion.div>

        {/* Collections Grid */}
        <div className="space-y-24">
          {collections.map((collection, index) => (
            <motion.div
              key={collection.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className={`grid lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                <div className={`${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <Card className="overflow-hidden group" data-testid={`collection-${collection.id}`}>
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img
                        src={collection.image}
                        alt={collection.name}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                    </div>
                  </Card>
                </div>

                <div className={`space-y-6 ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <div className="flex items-center gap-3 flex-wrap">
                    <Badge variant="outline" className="gap-2">
                      <MapPin className="h-3 w-3" />
                      {collection.region}
                    </Badge>
                    <Badge variant="secondary">
                      {collection.items} {language === 'ar' ? 'قطعة' : 'items'}
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <h2 className="font-serif text-4xl font-bold">
                      {language === 'ar' ? collection.nameAr : collection.name}
                    </h2>
                    <p className="text-sm uppercase tracking-wider text-muted-foreground">
                      {language === 'ar' ? 'من تصميم' : 'By'} {collection.designer}
                    </p>
                  </div>

                  <p className="text-lg text-muted-foreground leading-relaxed">
                    {collection.description}
                  </p>

                  <Link href={`/shop?category=${collection.id}`}>
                    <Button size="lg" className="gap-2" data-testid={`button-view-${collection.id}`}>
                      {t('viewCollection')}
                    </Button>
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Designers Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-32"
        >
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">
              {language === 'ar' ? 'مصممونا' : 'Our Designers'}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {language === 'ar'
                ? 'تعرفوا على أبرز المصممين الخليجيين المتخصصين في الأزياء الفاخرة'
                : 'Meet the leading Gulf designers specializing in luxury fashion'}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {designers.map((designer, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="p-8 text-center hover-elevate transition-all">
                  <div className="h-24 w-24 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="font-serif text-3xl font-bold text-primary">
                      {designer.name.charAt(0)}
                    </span>
                  </div>
                  <h3 className="font-serif text-2xl font-semibold mb-2">{designer.name}</h3>
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{designer.region}</span>
                  </div>
                  <Badge variant="secondary" className="mb-4">
                    {designer.specialty}
                  </Badge>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {designer.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
