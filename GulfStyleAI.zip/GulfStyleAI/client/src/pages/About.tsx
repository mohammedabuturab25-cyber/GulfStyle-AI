import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { Sparkles, Heart, Globe, Users } from "lucide-react";
import { motion } from "framer-motion";

export default function About() {
  const { language } = useLanguage();

  const values = [
    {
      icon: Sparkles,
      title: language === 'ar' ? 'الابتكار' : 'Innovation',
      description: language === 'ar'
        ? 'نستخدم أحدث تقنيات الذكاء الاصطناعي لتقديم تجربة تسوق فريدة'
        : 'We use cutting-edge AI technology to deliver a unique shopping experience',
    },
    {
      icon: Heart,
      title: language === 'ar' ? 'الاحترام الثقافي' : 'Cultural Respect',
      description: language === 'ar'
        ? 'نحترم ونحتفي بالتقاليد والقيم الخليجية في كل ما نقدمه'
        : 'We respect and celebrate Gulf traditions and values in everything we offer',
    },
    {
      icon: Globe,
      title: language === 'ar' ? 'الفخامة المحلية' : 'Local Luxury',
      description: language === 'ar'
        ? 'ندعم ونبرز المصممين الخليجيين وأعمالهم الاستثنائية'
        : 'We support and showcase Gulf designers and their exceptional work',
    },
    {
      icon: Users,
      title: language === 'ar' ? 'المجتمع' : 'Community',
      description: language === 'ar'
        ? 'نبني مجتمعاً من عشاق الموضة المحتشمة والأناقة الراقية'
        : 'We build a community of modest fashion enthusiasts and elegant style',
    },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6">
            {language === 'ar' ? 'عن GulfStyle AI' : 'About GulfStyle AI'}
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {language === 'ar'
              ? 'رحلتنا في دمج الذكاء الاصطناعي مع الأناقة الخليجية'
              : 'Our journey in combining AI with Gulf elegance'}
          </p>
        </motion.div>

        {/* Mission Statement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-24"
        >
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-12 text-center">
              <h2 className="font-serif text-3xl md:text-4xl font-bold mb-6">
                {language === 'ar' ? 'مهمتنا' : 'Our Mission'}
              </h2>
              <p className="text-lg text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                {language === 'ar'
                  ? 'نسعى لإعادة تعريف تجربة التسوق للأزياء المحتشمة الفاخرة من خلال الجمع بين التكنولوجيا المتقدمة والقيم الثقافية الأصيلة. نهدف إلى تمكين كل امرأة وكل رجل في منطقة الخليج من اكتشاف أسلوبهم الفريد الذي يعكس هويتهم وثقافتهم بكل فخر وأناقة.'
                  : 'We aim to redefine the luxury modest fashion shopping experience by combining advanced technology with authentic cultural values. Our goal is to empower every woman and man in the Gulf region to discover their unique style that reflects their identity and culture with pride and elegance.'}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-24"
        >
          <div className="text-center mb-12">
            <h2 className="font-serif text-4xl font-bold mb-4">
              {language === 'ar' ? 'قيمنا' : 'Our Values'}
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="h-full hover-elevate transition-all" data-testid={`card-value-${index}`}>
                    <CardContent className="p-8 text-center space-y-4">
                      <div className="h-16 w-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                        <Icon className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="font-serif text-xl font-semibold">{value.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Story */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <h2 className="font-serif text-4xl font-bold mb-4">
              {language === 'ar' ? 'قصتنا' : 'Our Story'}
            </h2>
          </div>

          <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              {language === 'ar'
                ? 'ولدت فكرة GulfStyle AI من إيماننا العميق بأن الموضة المحتشمة ليست مجرد أزياء، بل هي تعبير عن الهوية والثقافة. لاحظنا أن المرأة الخليجية العصرية تبحث عن تجربة تسوق تجمع بين الأصالة والابتكار، بين التقاليد والتكنولوجيا.'
                : 'The idea of GulfStyle AI was born from our deep belief that modest fashion is not just clothing, but an expression of identity and culture. We noticed that the modern Gulf woman seeks a shopping experience that combines authenticity with innovation, tradition with technology.'}
            </p>
            <p>
              {language === 'ar'
                ? 'مع تطور تقنيات الذكاء الاصطناعي، رأينا فرصة فريدة لإنشاء منصة تفهم احتياجات عملائنا بعمق وتقدم لهم توصيات مخصصة تحترم قيمهم وتعكس ذوقهم الرفيع. هكذا ظهرت "ليلى"، مساعدتنا الذكية التي تجمع بين الخبرة في الموضة والتكنولوجيا المتقدمة.'
                : 'With the evolution of AI technology, we saw a unique opportunity to create a platform that deeply understands our customers\' needs and provides them with personalized recommendations that respect their values and reflect their refined taste. Thus "Layla" was born, our intelligent assistant that combines fashion expertise with advanced technology.'}
            </p>
            <p>
              {language === 'ar'
                ? 'اليوم، نفخر بأن نكون جسراً يربط بين أرقى المصممين الخليجيين وعشاق الأزياء المحتشمة، ونسعى دائماً لتقديم تجربة تسوق لا مثيل لها تحتفي بجمال وأناقة الثقافة الخليجية.'
                : 'Today, we are proud to be a bridge connecting the finest Gulf designers with modest fashion enthusiasts, always striving to deliver an unparalleled shopping experience that celebrates the beauty and elegance of Gulf culture.'}
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
