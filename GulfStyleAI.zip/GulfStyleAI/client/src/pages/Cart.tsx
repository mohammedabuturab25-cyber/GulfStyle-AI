import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { ShoppingBag, Trash2, Plus, Minus } from "lucide-react";
import { motion } from "framer-motion";

export default function Cart() {
  const { t, language } = useLanguage();
  const [cartItems, setCartItems] = useState<any[]>([]);

  const updateQuantity = (id: string, delta: number) => {
    setCartItems(items =>
      items.map(item =>
        item.id === id
          ? { ...item, quantity: Math.max(1, item.quantity + delta) }
          : item
      )
    );
  };

  const removeItem = (id: string) => {
    setCartItems(items => items.filter(item => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-4">
            {t('shoppingCart')}
          </h1>
        </motion.div>

        {cartItems.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="p-16 text-center">
              <div className="max-w-md mx-auto space-y-6">
                <div className="h-24 w-24 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                  <ShoppingBag className="h-12 w-12 text-primary" />
                </div>
                <div className="space-y-2">
                  <h2 className="font-serif text-2xl font-semibold">{t('emptyCart')}</h2>
                  <p className="text-muted-foreground">
                    {language === 'ar'
                      ? 'ابدأي التسوق واكتشفي مجموعاتنا الفاخرة'
                      : 'Start shopping and discover our luxury collections'}
                  </p>
                </div>
                <Link href="/shop">
                  <Button size="lg" data-testid="button-continue-shopping">
                    {t('continueShopping')}
                  </Button>
                </Link>
              </div>
            </Card>
          </motion.div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex gap-6">
                        <div className="w-24 h-32 flex-shrink-0 overflow-hidden rounded-md">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 space-y-3">
                          <div className="flex justify-between gap-4">
                            <div>
                              <h3 className="font-serif text-lg font-semibold">{item.name}</h3>
                              <p className="text-sm text-muted-foreground">{item.designer}</p>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => removeItem(item.id)}
                              data-testid={`button-remove-${item.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'المقاس:' : 'Size:'} {item.size}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => updateQuantity(item.id, -1)}
                                data-testid={`button-decrease-${item.id}`}
                                className="h-8 w-8"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <span className="w-12 text-center font-medium">{item.quantity}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => updateQuantity(item.id, 1)}
                                data-testid={`button-increase-${item.id}`}
                                className="h-8 w-8"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                            <p className="font-serif text-xl font-bold">
                              {(parseFloat(item.price) * item.quantity).toFixed(2)} {item.currency}
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Card className="sticky top-24">
                <CardContent className="p-8 space-y-6">
                  <h2 className="font-serif text-2xl font-semibold">
                    {language === 'ar' ? 'ملخص الطلب' : 'Order Summary'}
                  </h2>

                  <div className="space-y-3">
                    <div className="flex justify-between text-muted-foreground">
                      <span>{t('subtotal')}</span>
                      <span>{subtotal.toFixed(2)} AED</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>{language === 'ar' ? 'الشحن' : 'Shipping'}</span>
                      <span>{language === 'ar' ? 'مجاني' : 'Free'}</span>
                    </div>
                    <div className="border-t pt-3">
                      <div className="flex justify-between font-serif text-xl font-bold">
                        <span>{t('total')}</span>
                        <span>{subtotal.toFixed(2)} AED</span>
                      </div>
                    </div>
                  </div>

                  <Link href="/checkout">
                    <Button size="lg" className="w-full" data-testid="button-checkout">
                      {t('checkout')}
                    </Button>
                  </Link>

                  <Link href="/shop">
                    <Button variant="outline" size="lg" className="w-full" data-testid="button-continue-shopping-summary">
                      {t('continueShopping')}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}
