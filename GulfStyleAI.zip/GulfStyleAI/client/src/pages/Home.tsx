import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, ShoppingBag, Users, Heart } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import heroImage from "@assets/generated_images/Luxury_abaya_hero_image_3bac2a1f.png";
import abayasImage from "@assets/generated_images/Abayas_collection_showcase_ec1506f0.png";
import thobesImage from "@assets/generated_images/Thobes_collection_display_16d9a5a5.png";
import kaftansImage from "@assets/generated_images/Kaftans_evening_wear_collection_3b94247d.png";

export default function Home() {
  const { t } = useLanguage();

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const features = [
    {
      icon: Sparkles,
      title: t('language') === 'ar' ? 'ليلى - مصممتك الذكية' : 'Layla - AI Stylist',
      description: t('language') === 'ar' 
        ? 'احصلي على توصيات أزياء مخصصة باستخدام الذكاء الاصطناعي'
        : 'Get personalized fashion recommendations powered by AI',
    },
    {
      icon: ShoppingBag,
      title: t('language') === 'ar' ? 'تسوق فاخر' : 'Luxury Shopping',
      description: t('language') === 'ar'
        ? 'اكتشفي مجموعات حصرية من مصممي الخليج'
        : 'Discover exclusive collections from Gulf designers',
    },
    {
      icon: Users,
      title: t('language') === 'ar' ? 'إلهام المؤثرين' : 'Influencer Inspiration',
      description: t('language') === 'ar'
        ? 'تابعي أحدث صيحات الموضة المحتشمة'
        : 'Follow the latest modest fashion trends',
    },
    {
      icon: Heart,
      title: t('language') === 'ar' ? 'خزانتك الذكية' : 'Smart Closet',
      description: t('language') === 'ar'
        ? 'نظمي ملابسك واحصلي على اقتراحات تنسيق'
        : 'Organize your wardrobe and get outfit suggestions',
    },
  ];

  const collections = [
    { name: t('luxuryAbayas'), image: abayasImage, category: 'abayas' },
    { name: t('elegantThobes'), image: thobesImage, category: 'thobes' },
    { name: t('eveningKaftans'), image: kaftansImage, category: 'kaftans' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Gulf Style Fashion"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/40" />
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div {...fadeIn} className="space-y-8">
              <div className="space-y-4">
                <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-bold tracking-wide leading-tight">
                  {t('heroTitle')}
                </h1>
                <p className="font-serif text-xl md:text-2xl text-primary">
                  {t('heroSubtitle')}
                </p>
                <p className="text-lg text-muted-foreground max-w-xl leading-relaxed">
                  {t('heroDescription')}
                </p>
              </div>

              <div className="flex flex-wrap gap-4">
                <Link href="/ai-stylist">
                  <Button size="lg" className="px-8 gap-2" data-testid="button-start-styling">
                    <Sparkles className="h-5 w-5" />
                    {t('startStyling')}
                  </Button>
                </Link>
                <Link href="/collections">
                  <Button size="lg" variant="outline" className="px-8 backdrop-blur-md" data-testid="button-explore-collections">
                    {t('exploreCollections')}
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">
              {t('language') === 'ar' ? 'لماذا GulfStyle AI؟' : 'Why GulfStyle AI?'}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t('language') === 'ar'
                ? 'تجربة تسوق فريدة تجمع بين التكنولوجيا والأناقة الخليجية'
                : 'A unique shopping experience combining technology and Gulf elegance'}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="h-full hover-elevate transition-all">
                    <CardContent className="p-8 space-y-4">
                      <div className="h-14 w-14 rounded-md bg-primary/10 flex items-center justify-center">
                        <Icon className="h-7 w-7 text-primary" />
                      </div>
                      <h3 className="font-serif text-xl font-semibold">{feature.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Collections Preview */}
      <section className="py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4">
              {t('gulfCollections')}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t('language') === 'ar'
                ? 'اكتشفي مجموعاتنا الفاخرة من أرقى المصممين الخليجيين'
                : 'Discover our luxury collections from the finest Gulf designers'}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {collections.map((collection, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Link href={`/shop?category=${collection.category}`}>
                  <Card className="overflow-hidden hover-elevate transition-all cursor-pointer group" data-testid={`collection-card-${collection.category}`}>
                    <div className="relative aspect-[4/5] overflow-hidden">
                      <img
                        src={collection.image}
                        alt={collection.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/20 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-8">
                        <h3 className="font-serif text-2xl font-bold text-foreground mb-2">
                          {collection.name}
                        </h3>
                        <Button variant="outline" className="backdrop-blur-md" data-testid={`button-view-${collection.category}`}>
                          {t('viewCollection')}
                        </Button>
                      </div>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-primary/5">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto space-y-8"
          >
            <h2 className="font-serif text-4xl md:text-5xl font-bold">
              {t('language') === 'ar' ? 'ابدأي رحلتك مع ليلى' : 'Start Your Journey with Layla'}
            </h2>
            <p className="text-lg text-muted-foreground">
              {t('language') === 'ar'
                ? 'دعي الذكاء الاصطناعي يساعدك في اكتشاف أسلوبك المثالي'
                : 'Let AI help you discover your perfect style today'}
            </p>
            <Link href="/ai-stylist">
              <Button size="lg" className="px-12" data-testid="button-meet-layla">
                <Sparkles className="h-5 w-5 me-2" />
                {t('meetLayla')}
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
