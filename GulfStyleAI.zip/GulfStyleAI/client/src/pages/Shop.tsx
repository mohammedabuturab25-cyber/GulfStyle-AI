import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/contexts/LanguageContext";
import { Product } from "@shared/schema";
import { Loader2, SlidersHorizontal } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Shop() {
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [modestyFilter, setModestyFilter] = useState<string>("all");
  const [occasionFilter, setOccasionFilter] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', categoryFilter, modestyFilter, occasionFilter],
  });

  const handleAddToCart = (product: Product) => {
    toast({
      title: language === 'ar' ? 'تمت الإضافة للسلة' : 'Added to Cart',
      description: language === 'ar' 
        ? `تمت إضافة ${product.nameAr || product.name} إلى سلة التسوق`
        : `${product.name} has been added to your cart`,
    });
  };

  const categories = [
    { value: "all", label: language === 'ar' ? 'الكل' : 'All' },
    { value: "abayas", label: language === 'ar' ? 'عباءات' : 'Abayas' },
    { value: "thobes", label: language === 'ar' ? 'ثياب' : 'Thobes' },
    { value: "kaftans", label: language === 'ar' ? 'قفاطين' : 'Kaftans' },
    { value: "scarves", label: language === 'ar' ? 'أوشحة' : 'Scarves' },
    { value: "perfumes", label: language === 'ar' ? 'عطور' : 'Perfumes' },
  ];

  const modestyLevels = [
    { value: "all", label: language === 'ar' ? 'الكل' : 'All' },
    { value: "very modest", label: language === 'ar' ? 'محتشم جداً' : 'Very Modest' },
    { value: "modest", label: language === 'ar' ? 'محتشم' : 'Modest' },
    { value: "elegant", label: language === 'ar' ? 'أنيق' : 'Elegant' },
  ];

  const occasions = [
    { value: "all", label: language === 'ar' ? 'الكل' : 'All' },
    { value: "casual", label: language === 'ar' ? 'يومي' : 'Casual' },
    { value: "work", label: language === 'ar' ? 'عمل' : 'Work' },
    { value: "evening", label: language === 'ar' ? 'سهرة' : 'Evening' },
    { value: "wedding", label: language === 'ar' ? 'زفاف' : 'Wedding' },
    { value: "special", label: language === 'ar' ? 'مناسبة خاصة' : 'Special' },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-4">
            {t('shop')}
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            {language === 'ar'
              ? 'اكتشفي مجموعتنا الفاخرة من الأزياء المحتشمة من أرقى المصممين الخليجيين'
              : 'Discover our luxury collection of modest fashion from the finest Gulf designers'}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar - Desktop */}
          <div className="hidden lg:block">
            <Card className="sticky top-24">
              <CardContent className="p-6 space-y-6">
                <div className="flex items-center gap-2 pb-4 border-b">
                  <SlidersHorizontal className="h-5 w-5 text-primary" />
                  <h2 className="font-serif text-xl font-semibold">{t('filterBy')}</h2>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">{t('category')}</label>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger data-testid="select-category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">{t('modestyLevel')}</label>
                  <Select value={modestyFilter} onValueChange={setModestyFilter}>
                    <SelectTrigger data-testid="select-modesty">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {modestyLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">{t('occasion')}</label>
                  <Select value={occasionFilter} onValueChange={setOccasionFilter}>
                    <SelectTrigger data-testid="select-occasion">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {occasions.map((occ) => (
                        <SelectItem key={occ.value} value={occ.value}>
                          {occ.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setCategoryFilter("all");
                    setModestyFilter("all");
                    setOccasionFilter("all");
                  }}
                  data-testid="button-clear-filters"
                >
                  {language === 'ar' ? 'مسح الفلاتر' : 'Clear Filters'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Mobile Filters Toggle */}
          <div className="lg:hidden col-span-full">
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="w-full gap-2"
              data-testid="button-toggle-filters"
            >
              <SlidersHorizontal className="h-4 w-4" />
              {t('filterBy')}
            </Button>

            {showFilters && (
              <Card className="mt-4">
                <CardContent className="p-6 space-y-4">
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('category')} />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={modestyFilter} onValueChange={setModestyFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('modestyLevel')} />
                    </SelectTrigger>
                    <SelectContent>
                      {modestyLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={occasionFilter} onValueChange={setOccasionFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('occasion')} />
                    </SelectTrigger>
                    <SelectContent>
                      {occasions.map((occ) => (
                        <SelectItem key={occ.value} value={occ.value}>
                          {occ.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Products Grid */}
          <div className="lg:col-span-3">
            {isLoading ? (
              <div className="flex items-center justify-center py-24">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : products && products.length > 0 ? (
              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-6" data-testid="products-grid">
                {products.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">
                  {language === 'ar' ? 'لا توجد منتجات متاحة' : 'No products available'}
                </p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
