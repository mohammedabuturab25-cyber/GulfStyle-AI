import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { InfluencerPost } from "@shared/schema";
import { Heart, Share2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Influencers() {
  const { t, language } = useLanguage();

  const { data: posts, isLoading } = useQuery<InfluencerPost[]>({
    queryKey: ['/api/influencer-posts'],
  });

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-6">
            {t('influencers')}
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {language === 'ar'
              ? 'استوحي أفكارك من أحدث صيحات الموضة المحتشمة'
              : 'Get inspired by the latest modest fashion trends'}
          </p>
        </motion.div>

        {/* Posts Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : posts && posts.length > 0 ? (
          <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
            {posts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="break-inside-avoid"
              >
                <Card className="overflow-hidden hover-elevate transition-all group" data-testid={`influencer-post-${post.id}`}>
                  <div className="relative overflow-hidden">
                    <img
                      src={post.imageUrl}
                      alt={post.caption}
                      className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-6 space-y-4">
                    <div className="space-y-2">
                      <p className="font-semibold">{post.influencerName}</p>
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {language === 'ar' && post.captionAr ? post.captionAr : post.caption}
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {post.tags.slice(0, 3).map((tag, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t">
                      <Button variant="ghost" size="sm" className="gap-2" data-testid={`button-like-${post.id}`}>
                        <Heart className="h-4 w-4" />
                        <span className="text-sm">{post.likes}</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-2" data-testid={`button-share-${post.id}`}>
                        <Share2 className="h-4 w-4" />
                        {language === 'ar' ? 'مشاركة' : 'Share'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">
              {language === 'ar' ? 'لا توجد منشورات متاحة' : 'No posts available'}
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
