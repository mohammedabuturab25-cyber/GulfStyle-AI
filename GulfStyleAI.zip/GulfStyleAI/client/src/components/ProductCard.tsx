import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Heart } from "lucide-react";
import { Product } from "@shared/schema";
import { useLanguage } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const { language } = useLanguage();

  const displayName = language === 'ar' && product.nameAr ? product.nameAr : product.name;
  const displayDescription = language === 'ar' && product.descriptionAr ? product.descriptionAr : product.description;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden hover-elevate transition-all group h-full flex flex-col" data-testid={`product-card-${product.id}`}>
        <div className="relative aspect-[4/5] overflow-hidden">
          <img
            src={product.images[0]}
            alt={displayName}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-3 right-3 bg-background/80 backdrop-blur-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            data-testid={`button-wishlist-${product.id}`}
          >
            <Heart className="h-5 w-5" />
          </Button>
          {!product.inStock && (
            <div className="absolute inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center">
              <Badge variant="secondary" className="text-sm">
                {language === 'ar' ? 'غير متوفر' : 'Out of Stock'}
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-6 flex-1 flex flex-col gap-3">
          <div className="space-y-2 flex-1">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-xs uppercase tracking-wider text-muted-foreground mb-1">
                  {product.designer}
                </p>
                <h3 className="font-serif text-lg font-semibold line-clamp-2" data-testid={`text-product-name-${product.id}`}>
                  {displayName}
                </h3>
              </div>
              <Badge variant="outline" className="shrink-0 text-xs">
                {product.designerRegion}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {displayDescription}
            </p>
          </div>

          <div className="flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-xs">
              {product.modestyLevel}
            </Badge>
            {product.occasion.slice(0, 2).map((occ, idx) => (
              <Badge key={idx} variant="outline" className="text-xs">
                {occ}
              </Badge>
            ))}
          </div>

          <div className="flex items-center justify-between gap-3 pt-3 border-t">
            <div>
              <p className="font-serif text-2xl font-bold" data-testid={`text-product-price-${product.id}`}>
                {product.price} <span className="text-sm text-muted-foreground">{product.currency}</span>
              </p>
            </div>
            <Button
              size="sm"
              onClick={() => onAddToCart?.(product)}
              disabled={!product.inStock}
              className="gap-2"
              data-testid={`button-add-to-cart-${product.id}`}
            >
              <ShoppingCart className="h-4 w-4" />
              {language === 'ar' ? 'أضف' : 'Add'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
