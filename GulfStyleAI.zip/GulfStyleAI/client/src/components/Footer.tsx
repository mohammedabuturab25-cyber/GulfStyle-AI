import { Link } from "wouter";
import { Sparkles, Instagram, Facebook, Twitter } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="border-t bg-card mt-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="font-serif text-2xl font-semibold tracking-wide">
                GulfStyle <span className="text-primary">AI</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {t('language') === 'ar' 
                ? 'أناقة الخليج الفاخرة مدعومة بالذكاء الاصطناعي' 
                : 'AI-Powered Gulf Luxury Fashion'}
            </p>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="rounded-md" data-testid="button-social-instagram">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Button>
              <Button variant="ghost" size="icon" className="rounded-md" data-testid="button-social-facebook">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Button>
              <Button variant="ghost" size="icon" className="rounded-md" data-testid="button-social-twitter">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-4">{t('about')}</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about">
                  <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-about">
                    {t('aboutUs')}
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-mission">
                    {t('ourMission')}
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-contact">
                    {t('contact')}
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Collections */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-4">{t('collections')}</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/collections">
                  <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-abayas">
                    {t('luxuryAbayas')}
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/collections">
                  <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-thobes">
                    {t('elegantThobes')}
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/collections">
                  <a className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-kaftans">
                    {t('eveningKaftans')}
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-4">{t('newsletter')}</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {t('subscribeNewsletter')}
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder={t('emailPlaceholder')}
                data-testid="input-newsletter-email"
                className="flex-1"
              />
              <Button data-testid="button-newsletter-subscribe" variant="default">
                {t('subscribe')}
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t mt-12 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} GulfStyle AI. {t('allRightsReserved')}.
          </p>
        </div>
      </div>
    </footer>
  );
}
