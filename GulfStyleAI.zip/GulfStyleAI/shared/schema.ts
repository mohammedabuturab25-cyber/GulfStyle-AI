import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Product Categories for Gulf Fashion
export const productCategories = ["abayas", "thobes", "kaftans", "scarves", "perfumes", "accessories"] as const;
export const modestyLevels = ["very modest", "modest", "elegant"] as const;
export const occasions = ["casual", "work", "evening", "wedding", "special"] as const;
export const designerRegions = ["dubai", "muscat", "riyadh", "doha", "other"] as const;

// Products Schema
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  nameAr: text("name_ar"),
  description: text("description").notNull(),
  descriptionAr: text("description_ar"),
  category: text("category").notNull(),
  designer: text("designer").notNull(),
  designerRegion: text("designer_region").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("AED"),
  images: text("images").array().notNull(),
  modestyLevel: text("modesty_level").notNull(),
  occasion: text("occasion").array().notNull(),
  colors: text("colors").array().notNull(),
  sizes: text("sizes").array().notNull(),
  inStock: boolean("in_stock").notNull().default(true),
  featured: boolean("featured").notNull().default(false),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// AI Styling Requests Schema
export const stylingRequests = pgTable("styling_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userInput: text("user_input").notNull(),
  imageUrl: text("image_url"),
  preferences: text("preferences"),
  occasion: text("occasion"),
  budget: text("budget"),
  aiResponse: text("ai_response"),
  recommendedProducts: text("recommended_products").array(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertStylingRequestSchema = createInsertSchema(stylingRequests).omit({
  id: true,
  createdAt: true,
});

export type InsertStylingRequest = z.infer<typeof insertStylingRequestSchema>;
export type StylingRequest = typeof stylingRequests.$inferSelect;

// Smart Closet Items Schema
export const closetItems = pgTable("closet_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  colors: text("colors").array().notNull(),
  occasion: text("occasion").array().notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertClosetItemSchema = createInsertSchema(closetItems).omit({
  id: true,
  createdAt: true,
});

export type InsertClosetItem = z.infer<typeof insertClosetItemSchema>;
export type ClosetItem = typeof closetItems.$inferSelect;

// Influencer Posts Schema
export const influencerPosts = pgTable("influencer_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  influencerName: text("influencer_name").notNull(),
  imageUrl: text("image_url").notNull(),
  caption: text("caption").notNull(),
  captionAr: text("caption_ar"),
  tags: text("tags").array().notNull(),
  products: text("products").array(),
  likes: integer("likes").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertInfluencerPostSchema = createInsertSchema(influencerPosts).omit({
  id: true,
  createdAt: true,
});

export type InsertInfluencerPost = z.infer<typeof insertInfluencerPostSchema>;
export type InfluencerPost = typeof influencerPosts.$inferSelect;

// Shopping Cart Schema
export const cartItems = pgTable("cart_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: text("product_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  size: text("size").notNull(),
  addedAt: text("added_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertCartItemSchema = createInsertSchema(cartItems).omit({
  id: true,
  addedAt: true,
});

export type InsertCartItem = z.infer<typeof insertCartItemSchema>;
export type CartItem = typeof cartItems.$inferSelect;

// Users Schema (extended for future auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
