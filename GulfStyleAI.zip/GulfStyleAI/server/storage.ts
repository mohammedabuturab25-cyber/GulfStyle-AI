import {
  type User,
  type InsertUser,
  type Product,
  type InsertProduct,
  type StylingRequest,
  type InsertStylingRequest,
  type ClosetItem,
  type InsertClosetItem,
  type InfluencerPost,
  type InsertInfluencerPost,
  type CartItem,
  type InsertCartItem,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product methods
  getProducts(filters?: {
    category?: string;
    modestyLevel?: string;
    occasion?: string;
  }): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Styling Request methods
  createStylingRequest(request: InsertStylingRequest): Promise<StylingRequest>;
  getStylingRequest(id: string): Promise<StylingRequest | undefined>;

  // Closet Item methods
  getClosetItems(): Promise<ClosetItem[]>;
  createClosetItem(item: InsertClosetItem): Promise<ClosetItem>;

  // Influencer Post methods
  getInfluencerPosts(): Promise<InfluencerPost[]>;
  createInfluencerPost(post: InsertInfluencerPost): Promise<InfluencerPost>;

  // Cart methods
  getCartItems(): Promise<CartItem[]>;
  addCartItem(item: InsertCartItem): Promise<CartItem>;
  removeCartItem(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private stylingRequests: Map<string, StylingRequest>;
  private closetItems: Map<string, ClosetItem>;
  private influencerPosts: Map<string, InfluencerPost>;
  private cartItems: Map<string, CartItem>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.stylingRequests = new Map();
    this.closetItems = new Map();
    this.influencerPosts = new Map();
    this.cartItems = new Map();

    // Seed with sample data
    this.seedData();
  }

  private seedData() {
    // Sample products
    const sampleProducts: InsertProduct[] = [
      {
        name: "Elegant Pearl Abaya",
        nameAr: "عباءة اللؤلؤ الأنيقة",
        description: "Luxurious pearl white abaya with delicate gold embroidery and flowing silhouette",
        descriptionAr: "عباءة لؤلؤية فاخرة مع تطريز ذهبي رقيق وقصة انسيابية",
        category: "abayas",
        designer: "Noor Al Sharq",
        designerRegion: "dubai",
        price: "1200",
        currency: "AED",
        images: ["https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=800"],
        modestyLevel: "very modest",
        occasion: ["evening", "special", "wedding"],
        colors: ["pearl", "gold"],
        sizes: ["S", "M", "L", "XL"],
        inStock: true,
        featured: true,
      },
      {
        name: "Royal Emerald Kaftan",
        nameAr: "قفطان الزمرد الملكي",
        description: "Stunning emerald kaftan with intricate beading perfect for special occasions",
        descriptionAr: "قفطان زمردي مذهل مع خرز معقد مثالي للمناسبات الخاصة",
        category: "kaftans",
        designer: "Oman Elegance",
        designerRegion: "muscat",
        price: "2500",
        currency: "AED",
        images: ["https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800"],
        modestyLevel: "elegant",
        occasion: ["evening", "wedding"],
        colors: ["emerald", "gold"],
        sizes: ["S", "M", "L"],
        inStock: true,
        featured: true,
      },
      {
        name: "Classic White Thobe",
        nameAr: "ثوب أبيض كلاسيكي",
        description: "Premium cotton thobe with modern tailoring and traditional elegance",
        descriptionAr: "ثوب قطني فاخر بتفصيل عصري وأناقة تقليدية",
        category: "thobes",
        designer: "Riyadh Couture",
        designerRegion: "riyadh",
        price: "800",
        currency: "AED",
        images: ["https://images.unsplash.com/photo-1622445275576-721325763eda?w=800"],
        modestyLevel: "very modest",
        occasion: ["casual", "work", "special"],
        colors: ["white"],
        sizes: ["M", "L", "XL", "XXL"],
        inStock: true,
        featured: false,
      },
    ];

    sampleProducts.forEach((product) => {
      const id = randomUUID();
      this.products.set(id, { ...product, id });
    });

    // Sample influencer posts
    const samplePosts: InsertInfluencerPost[] = [
      {
        influencerName: "Fatima Al-Mansouri",
        imageUrl: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800",
        caption: "Loving this elegant abaya for evening events ✨",
        captionAr: "أحب هذه العباءة الأنيقة للمناسبات المسائية ✨",
        tags: ["abayas", "evening", "dubai"],
        products: [],
        likes: 342,
      },
      {
        influencerName: "Noura Abdullah",
        imageUrl: "https://images.unsplash.com/photo-1617922001439-4a2e6562f328?w=800",
        caption: "Perfect kaftan for special celebrations",
        captionAr: "قفطان مثالي للاحتفالات الخاصة",
        tags: ["kaftans", "wedding", "luxury"],
        products: [],
        likes: 521,
      },
    ];

    samplePosts.forEach((post) => {
      const id = randomUUID();
      const createdAt = new Date().toISOString();
      this.influencerPosts.set(id, { ...post, id, createdAt });
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Product methods
  async getProducts(filters?: {
    category?: string;
    modestyLevel?: string;
    occasion?: string;
  }): Promise<Product[]> {
    let products = Array.from(this.products.values());

    if (filters?.category && filters.category !== "all") {
      products = products.filter((p) => p.category === filters.category);
    }
    if (filters?.modestyLevel && filters.modestyLevel !== "all") {
      products = products.filter((p) => p.modestyLevel === filters.modestyLevel);
    }
    if (filters?.occasion && filters.occasion !== "all") {
      products = products.filter((p) => p.occasion.includes(filters.occasion));
    }

    return products;
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id };
    this.products.set(id, product);
    return product;
  }

  // Styling Request methods
  async createStylingRequest(
    insertRequest: InsertStylingRequest,
  ): Promise<StylingRequest> {
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    const request: StylingRequest = { ...insertRequest, id, createdAt };
    this.stylingRequests.set(id, request);
    return request;
  }

  async getStylingRequest(id: string): Promise<StylingRequest | undefined> {
    return this.stylingRequests.get(id);
  }

  // Closet Item methods
  async getClosetItems(): Promise<ClosetItem[]> {
    return Array.from(this.closetItems.values());
  }

  async createClosetItem(insertItem: InsertClosetItem): Promise<ClosetItem> {
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    const item: ClosetItem = { ...insertItem, id, createdAt };
    this.closetItems.set(id, item);
    return item;
  }

  // Influencer Post methods
  async getInfluencerPosts(): Promise<InfluencerPost[]> {
    return Array.from(this.influencerPosts.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }

  async createInfluencerPost(
    insertPost: InsertInfluencerPost,
  ): Promise<InfluencerPost> {
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    const post: InfluencerPost = { ...insertPost, id, createdAt };
    this.influencerPosts.set(id, post);
    return post;
  }

  // Cart methods
  async getCartItems(): Promise<CartItem[]> {
    return Array.from(this.cartItems.values());
  }

  async addCartItem(insertItem: InsertCartItem): Promise<CartItem> {
    const id = randomUUID();
    const addedAt = new Date().toISOString();
    const item: CartItem = { ...insertItem, id, addedAt };
    this.cartItems.set(id, item);
    return item;
  }

  async removeCartItem(id: string): Promise<void> {
    this.cartItems.delete(id);
  }
}

export const storage = new MemStorage();
