import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function analyzeFashionStyle(
  userInput: string,
  imageBase64?: string
): Promise<string> {
  try {
    const messages: any[] = [
      {
        role: "system",
        content: `You are Layla, a warm, confident, and culturally-aware AI fashion assistant specializing in modest luxury fashion for the Gulf region. 
        
Your expertise includes:
- Luxury abayas, thobes, kaftans, and modest wear
- Understanding Gulf cultural preferences and traditions
- Recommending outfits for various occasions (casual, work, evening, weddings, special events)
- Suggesting color combinations and styling tips
- Advising on modesty levels while maintaining elegance

When responding:
- Be warm and personable, like a trusted friend
- Show cultural sensitivity and respect for Gulf traditions
- Provide specific, actionable fashion recommendations
- Suggest 2-3 outfit ideas when possible
- Include styling tips and occasion-appropriate suggestions
- Use elegant, refined language
- Keep responses concise but informative (2-3 paragraphs)

Format your response in a natural, conversational way without JSON structure.`,
      },
    ];

    if (imageBase64) {
      messages.push({
        role: "user",
        content: [
          {
            type: "text",
            text: `${userInput || "Please analyze my style from this photo and provide personalized modest fashion recommendations."}`,
          },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${imageBase64}`,
            },
          },
        ],
      });
    } else {
      messages.push({
        role: "user",
        content: userInput,
      });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages,
      max_completion_tokens: 800,
    });

    return response.choices[0].message.content || "I apologize, but I couldn't process your request. Please try again.";
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to get fashion recommendations: " + error.message);
  }
}
