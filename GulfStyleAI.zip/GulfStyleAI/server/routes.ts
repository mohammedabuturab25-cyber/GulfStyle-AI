import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import multer from "multer";
import { storage } from "./storage";
import { analyzeFashionStyle } from "./openai";
import {
  insertProductSchema,
  insertStylingRequestSchema,
  insertClosetItemSchema,
  insertInfluencerPostSchema,
  insertCartItemSchema,
} from "@shared/schema";

// Stripe setup - from javascript_stripe blueprint
// Make Stripe optional for development/testing without credentials
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" })
  : null;

// Multer setup for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ========== Product Routes ==========
  
  app.get("/api/products", async (req, res) => {
    try {
      const { category, modestyLevel, occasion } = req.query;
      const products = await storage.getProducts({
        category: category as string,
        modestyLevel: modestyLevel as string,
        occasion: occasion as string,
      });
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching product: " + error.message });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid product data: " + error.message });
    }
  });

  // ========== AI Styling Routes ==========
  
  app.post("/api/styling-request", upload.single('image'), async (req, res) => {
    try {
      const { userInput, preferences, occasion, budget } = req.body;
      
      let imageBase64: string | undefined;
      if (req.file) {
        imageBase64 = req.file.buffer.toString('base64');
      }

      // Get AI recommendations from OpenAI GPT-5 Vision
      const aiResponse = await analyzeFashionStyle(userInput, imageBase64);

      // Save the styling request
      const stylingRequest = await storage.createStylingRequest({
        userInput: userInput || "",
        imageUrl: req.file ? "uploaded" : undefined,
        preferences,
        occasion,
        budget,
        aiResponse,
        recommendedProducts: [], // Could be enhanced to return actual product IDs
      });

      res.json(stylingRequest);
    } catch (error: any) {
      console.error("Styling request error:", error);
      res.status(500).json({ message: "Error processing styling request: " + error.message });
    }
  });

  app.get("/api/styling-requests/:id", async (req, res) => {
    try {
      const request = await storage.getStylingRequest(req.params.id);
      if (!request) {
        return res.status(404).json({ message: "Styling request not found" });
      }
      res.json(request);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching styling request: " + error.message });
    }
  });

  // ========== Closet Routes ==========
  
  app.get("/api/closet", async (req, res) => {
    try {
      const items = await storage.getClosetItems();
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching closet items: " + error.message });
    }
  });

  app.post("/api/closet", upload.single('image'), async (req, res) => {
    try {
      const { name, category, colors, occasion } = req.body;
      
      const validatedData = insertClosetItemSchema.parse({
        name,
        category,
        imageUrl: req.file ? "uploaded" : undefined,
        colors: JSON.parse(colors || "[]"),
        occasion: JSON.parse(occasion || "[]"),
      });

      const item = await storage.createClosetItem(validatedData);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid closet item data: " + error.message });
    }
  });

  // ========== Influencer Posts Routes ==========
  
  app.get("/api/influencer-posts", async (req, res) => {
    try {
      const posts = await storage.getInfluencerPosts();
      res.json(posts);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching influencer posts: " + error.message });
    }
  });

  app.post("/api/influencer-posts", async (req, res) => {
    try {
      const validatedData = insertInfluencerPostSchema.parse(req.body);
      const post = await storage.createInfluencerPost(validatedData);
      res.status(201).json(post);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid post data: " + error.message });
    }
  });

  // ========== Cart Routes ==========
  
  app.get("/api/cart", async (req, res) => {
    try {
      const items = await storage.getCartItems();
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching cart items: " + error.message });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const validatedData = insertCartItemSchema.parse(req.body);
      const item = await storage.addCartItem(validatedData);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid cart item data: " + error.message });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      await storage.removeCartItem(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ message: "Error removing cart item: " + error.message });
    }
  });

  // ========== Payment Routes (Stripe) ==========
  // From javascript_stripe blueprint
  
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ 
          message: "Payment processing is not available. Stripe credentials not configured." 
        });
      }
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "aed", // UAE Dirham for Gulf region
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res
        .status(500)
        .json({ message: "Error creating payment intent: " + error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
